#!/bin/bash
# -*- ENCODING: UTF-8 -*-

CIDdir=/etc/ADM-db && [[ ! -d ${CIDdir} ]] && mkdir ${CIDdir}
SRC="${CIDdir}/sources" && [[ ! -d ${SRC} ]] && mkdir ${SRC}
CID="${CIDdir}/User-ID" && [[ ! -e ${CID} ]] && echo > ${CID}
keytxt="${CIDdir}/keys" && [[ ! -d ${keytxt} ]] && mkdir ${keytxt}
LINE="   -=-=-=-=--=-=-=-=--=-=-=-=--=-=-=-=--=-=-=-=--=-=-=-=-"

# Token del bot
bot_token="$(cat ${CIDdir}/token)"

msj_add () {
    [[ -z $bot_token ]] && exit
    ID=$1 && ID="$(echo $ID | awk '{print $1}' | sed -e 's/[^0-9]//ig')"
    [[ ${ID} -lt '999' ]] && ID='576145089'
    urlBOT="https://api.telegram.org/bot$bot_token/sendMessage"
    curl -s -X POST $urlBOT -d chat_id=$ID -d text="$(echo -e "$MENSAJE")" -d parse_mode="Markdown" &>/dev/null
}

#FUNCION DESTRUIR ID
unset i
for i in $(cat ${CID} | awk '{print $3}'); do 
    if [[ "$(date -d $(date '+%C%y-%m-%d') +%s)" -ge "$(date -d $i +%s)" ]]; then
        for id in $(cat ${CID} | grep "$i" | awk '{print $1}' | sed -e 's/[^a-z0-9 -]//ig'); do
            sed -i "/${id}/d" ${CID}
            echo -e " ID : ${id} REMOVIDO $i en $(date '+%C%y-%m-%d') - $(date +%R) " >> $HOME/killID.log
            
            MENSAJE="🎉 *¡Tu Membresía ha Finalizado!* 🎉\n\n"
            MENSAJE+="🚫 Desafortunadamente, tu acceso al BotGen ha sido desactivado.\n\n"
            MENSAJE+="⏳ *Fecha de Corte*: $(date '+%C%y-%m-%d') - $(date +%R)\n\n"
            MENSAJE+="📲 Si no tienes acceso al bot, usa el comando /id o selecciona la opción en el /menu y presiona el botón *ENVIAR AL ADM* para enviar tu ID automáticamente al administrador.\n\n"
            MENSAJE+="💡 También puedes revisar los *precios de las membresías* con el comando /price para obtener nuevamente acceso.\n\n"
            MENSAJE+="🔄 *Recuerda renovar tu Membresía* para seguir disfrutando de las claves ilimitadas del BotGen.\n\n"
            MENSAJE+="💬 Si tienes dudas, contacta con $(cat < /etc/ADM-db/resell)\n"
            MENSAJE+="$LINE\n"
            
            msj_add ${id}
        done
    fi
done

exit
